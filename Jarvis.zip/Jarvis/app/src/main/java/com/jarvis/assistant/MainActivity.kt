package com.jarvis.assistant

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.widget.*

class MainActivity : Activity() {
    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(40, 80, 40, 40) }

        root.addView(TextView(this).apply { text = "ДЖАРВИС"; textSize = 28f })

        val key = EditText(this).apply {
            hint = "Ключ Claude API (sk-ant-...)"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            setText(Prefs.apiKey(this@MainActivity))
        }
        root.addView(key)

        fun btn(title: String, onClick: () -> Unit) =
            root.addView(Button(this).apply { text = title; setOnClickListener { onClick() } })

        btn("1. Сохранить ключ") {
            Prefs.setApiKey(this, key.text.toString())
            Toast.makeText(this, "Сохранено", Toast.LENGTH_SHORT).show()
        }
        btn("2. Выдать разрешения") {
            requestPermissions(arrayOf(
                Manifest.permission.RECORD_AUDIO, Manifest.permission.CALL_PHONE,
                Manifest.permission.SEND_SMS, Manifest.permission.READ_CONTACTS,
                Manifest.permission.POST_NOTIFICATIONS
            ), 1)
        }
        btn("3. Включить спецвозможности (управление экраном)") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        btn("4. Без ограничений батареи") {
            startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                Uri.parse("package:$packageName")))
        }
        btn("▶ Запустить Джарвиса") { startForegroundService(Intent(this, JarvisService::class.java)) }
        btn("■ Остановить") { stopService(Intent(this, JarvisService::class.java)) }

        setContentView(ScrollView(this).apply { addView(root) })
    }
}
