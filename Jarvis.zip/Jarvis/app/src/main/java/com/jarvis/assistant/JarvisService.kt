package com.jarvis.assistant

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import kotlinx.coroutines.*
import java.util.Locale

class JarvisService : Service() {
    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private val handler = Handler(Looper.getMainLooper())
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var awaiting = false
    private var running = true

    private val wake = listOf("джарвис", "джарвіс", "jarvis", "жарвис")

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("jarvis", "Джарвис", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "jarvis")
            .setContentTitle("Джарвис слушает")
            .setContentText("Скажите: «Джарвис, ...»")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .build()
        startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)

        tts = TextToSpeech(this) { st ->
            if (st == TextToSpeech.SUCCESS) {
                tts?.language = Locale("ru", "RU")
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(id: String?) {}
                    override fun onError(id: String?) { handler.post { listen() } }
                    override fun onDone(id: String?) { handler.post { listen() } }
                })
                speak("Джарвис на связи")
            }
        }
        recognizer = SpeechRecognizer.createSpeechRecognizer(this).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onResults(b: Bundle?) {
                    val t = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull() ?: ""
                    handle(t)
                }
                override fun onError(e: Int) { handler.postDelayed({ listen() }, 600) }
                override fun onReadyForSpeech(p: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(v: Float) {}
                override fun onBufferReceived(b: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onPartialResults(b: Bundle?) {}
                override fun onEvent(t: Int, b: Bundle?) {}
            })
        }
    }

    private fun listen() {
        if (!running) return
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ru-RU")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
        }
        try { recognizer?.cancel(); recognizer?.startListening(i) } catch (_: Exception) {
            handler.postDelayed({ listen() }, 1000)
        }
    }

    private fun handle(text: String) {
        val low = text.lowercase().trim()
        val hasWake = wake.any { low.contains(it) }
        if (!awaiting && !hasWake) { listen(); return }
        var cmd = low
        wake.forEach { cmd = cmd.replace(it, "") }
        cmd = cmd.trim(' ', ',', '.')
        if (cmd.isEmpty()) { awaiting = true; speak("Слушаю"); return }
        awaiting = false
        scope.launch {
            val r = withContext(Dispatchers.IO) { Brain.ask(this@JarvisService, cmd) }
            Actions.run(this@JarvisService, r.optJSONObject("action"))
            speak(r.optString("say", "Готово"))
        }
    }

    private fun speak(t: String) {
        tts?.speak(t, TextToSpeech.QUEUE_FLUSH, null, "u${System.nanoTime()}")
    }

    override fun onDestroy() {
        running = false
        scope.cancel()
        recognizer?.destroy()
        tts?.shutdown()
        super.onDestroy()
    }
}
