package com.jarvis.assistant

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

object Brain {
    private const val MODEL = "claude-sonnet-5-5"
    private val history = JSONArray()

    private const val SYSTEM = """Ты Джарвис — голосовой ассистент на телефоне Android. Отвечай по-русски, кратко.
Ответ СТРОГО в JSON без markdown: {"say":"фраза для озвучки","action":null или объект}.
Типы action:
{"type":"call","target":"имя или номер"}
{"type":"sms","target":"имя или номер","text":"..."}
{"type":"open_app","name":"название приложения"}
{"type":"alarm","hour":7,"minute":30,"label":"..."}
{"type":"timer","seconds":300}
{"type":"flashlight","on":true}
{"type":"wifi"}
{"type":"music","cmd":"play|pause|next|prev"}
{"type":"volume","dir":"up|down"}
{"type":"back"} {"type":"home"} {"type":"recents"}
{"type":"click_text","text":"надпись на экране"}
{"type":"search","query":"..."}
Если действие не нужно — action null, просто ответь в say."""

    fun ask(ctx: Context, userText: String): JSONObject {
        val key = Prefs.apiKey(ctx)
        if (key.isBlank()) return JSONObject().put("say", "Сначала введите ключ API в настройках")

        history.put(JSONObject().put("role", "user").put("content", userText))
        while (history.length() > 12) history.remove(0)

        val body = JSONObject()
            .put("model", MODEL)
            .put("max_tokens", 500)
            .put("system", SYSTEM)
            .put("messages", history)

        return try {
            val c = URL("https://api.anthropic.com/v1/messages").openConnection() as HttpURLConnection
            c.requestMethod = "POST"
            c.connectTimeout = 15000
            c.readTimeout = 30000
            c.doOutput = true
            c.setRequestProperty("content-type", "application/json")
            c.setRequestProperty("x-api-key", key)
            c.setRequestProperty("anthropic-version", "2023-06-01")
            c.outputStream.use { it.write(body.toString().toByteArray()) }
            val code = c.responseCode
            val text = (if (code in 200..299) c.inputStream else c.errorStream).bufferedReader().readText()
            if (code !in 200..299) return JSONObject().put("say", "Ошибка API $code")
            val reply = JSONObject(text).getJSONArray("content").getJSONObject(0).getString("text")
            history.put(JSONObject().put("role", "assistant").put("content", reply))
            val s = reply.indexOf('{'); val e = reply.lastIndexOf('}')
            if (s >= 0 && e > s) JSONObject(reply.substring(s, e + 1)) else JSONObject().put("say", reply)
        } catch (ex: Exception) {
            JSONObject().put("say", "Нет связи с сервером")
        }
    }
}

object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("jarvis", Context.MODE_PRIVATE)
    fun apiKey(c: Context) = sp(c).getString("key", "") ?: ""
    fun setApiKey(c: Context, k: String) = sp(c).edit().putString("key", k.trim()).apply()
}
