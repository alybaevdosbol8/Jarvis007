package com.jarvis.assistant

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.content.Intent
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.provider.AlarmClock
import android.provider.ContactsContract
import android.provider.Settings
import android.telephony.SmsManager
import android.view.KeyEvent
import org.json.JSONObject

object Actions {
    private var torch = false

    private fun start(c: Context, i: Intent) { i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); c.startActivity(i) }

    private fun resolveNumber(c: Context, target: String): String? {
        if (target.any { it.isDigit() } && target.count { it.isLetter() } == 0) return target
        c.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER),
            "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?",
            arrayOf("%$target%"), null
        )?.use { if (it.moveToFirst()) return it.getString(0) }
        return null
    }

    fun run(c: Context, a: JSONObject?) {
        if (a == null || a.optString("type").isEmpty()) return
        try {
            when (a.getString("type")) {
                "call" -> resolveNumber(c, a.getString("target"))?.let {
                    start(c, Intent(Intent.ACTION_CALL, Uri.parse("tel:$it")))
                }
                "sms" -> resolveNumber(c, a.getString("target"))?.let {
                    val sm = c.getSystemService(SmsManager::class.java)
                    sm.sendMultipartTextMessage(it, null, sm.divideMessage(a.getString("text")), null, null)
                }
                "open_app" -> openApp(c, a.getString("name"))
                "alarm" -> start(c, Intent(AlarmClock.ACTION_SET_ALARM).apply {
                    putExtra(AlarmClock.EXTRA_HOUR, a.getInt("hour"))
                    putExtra(AlarmClock.EXTRA_MINUTES, a.optInt("minute", 0))
                    putExtra(AlarmClock.EXTRA_MESSAGE, a.optString("label", "Джарвис"))
                    putExtra(AlarmClock.EXTRA_SKIP_UI, true)
                })
                "timer" -> start(c, Intent(AlarmClock.ACTION_SET_TIMER).apply {
                    putExtra(AlarmClock.EXTRA_LENGTH, a.getInt("seconds"))
                    putExtra(AlarmClock.EXTRA_SKIP_UI, true)
                })
                "flashlight" -> {
                    val cm = c.getSystemService(Context.CAMERA_SERVICE) as CameraManager
                    torch = a.optBoolean("on", !torch)
                    val id = cm.cameraIdList.firstOrNull {
                        cm.getCameraCharacteristics(it)
                            .get(android.hardware.camera2.CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
                    }
                    if (id != null) cm.setTorchMode(id, torch)
                }
                "wifi" -> start(c, Intent(Settings.Panel.ACTION_INTERNET_CONNECTIVITY))
                "music" -> {
                    val code = when (a.optString("cmd")) {
                        "pause" -> KeyEvent.KEYCODE_MEDIA_PAUSE
                        "next" -> KeyEvent.KEYCODE_MEDIA_NEXT
                        "prev" -> KeyEvent.KEYCODE_MEDIA_PREVIOUS
                        else -> KeyEvent.KEYCODE_MEDIA_PLAY
                    }
                    val am = c.getSystemService(Context.AUDIO_SERVICE) as AudioManager
                    am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
                    am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
                }
                "volume" -> (c.getSystemService(Context.AUDIO_SERVICE) as AudioManager).adjustStreamVolume(
                    AudioManager.STREAM_MUSIC,
                    if (a.optString("dir") == "down") AudioManager.ADJUST_LOWER else AudioManager.ADJUST_RAISE,
                    AudioManager.FLAG_SHOW_UI
                )
                "back" -> JarvisAccessibility.instance?.performGlobalAction(AccessibilityService.GLOBAL_ACTION_BACK)
                "home" -> JarvisAccessibility.instance?.performGlobalAction(AccessibilityService.GLOBAL_ACTION_HOME)
                "recents" -> JarvisAccessibility.instance?.performGlobalAction(AccessibilityService.GLOBAL_ACTION_RECENTS)
                "click_text" -> JarvisAccessibility.instance?.clickByText(a.getString("text"))
                "search" -> start(c, Intent(Intent.ACTION_VIEW,
                    Uri.parse("https://www.google.com/search?q=" + Uri.encode(a.getString("query")))))
            }
        } catch (e: Exception) { /* нет разрешения или действие недоступно */ }
    }

    private fun openApp(c: Context, name: String) {
        val pm = c.packageManager
        val q = name.lowercase()
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val match = pm.queryIntentActivities(intent, 0).firstOrNull {
            it.loadLabel(pm).toString().lowercase().contains(q)
        } ?: return
        pm.getLaunchIntentForPackage(match.activityInfo.packageName)?.let { start(c, it) }
    }
}
